---
layout: single
title: "Diagnosing Model Misfit with Posterior Predictive Checks"
sidebar:
  - title: "Introduction to Bayesian Inference with Stan"
  - text: "January 19-20, 2017, Columbia University, New York"
  - title: "Instructors"
    text: "[__Jonah Gabry__](mailto:jonah@stan.fit) and [__Rob Trangucci__](mailto:robert.trangucci@gmail.com) (Columbia University, Stan Development Team, Stan Group Inc)"
  - title: "Special guest lecturer"
    text: "Andrew Gelman"
  - title: "Useful info"
    text: "__Wifi network__: Columbia University (not Columbia U Secure)"
comments:
image:
---

__Files__

* [R Markdown document](poisson-ppc.Rmd)
* [Generated HTML](poisson-ppc.html)
* [Stan program (poisson simple)](poisson-simple.stan)
* [Stan program (poisson hurdle)](poisson-hurdle.stan)
* [Data](count-data.R)
* [All files (zip)](ppcs.zip)

<br>
[(Back to course page)](http://stan.fit/training/stancon2017/intro/)